<?php
session_start();
include('libreria/componentes/header.php');
?>
<?php

include('libreria/componentes/footer.php');
?>
